.. _faq-index:

###################################
  Python Frequently Asked Questions
###################################

.. toctree::
   :maxdepth: 1

   general.rst
   programming.rst
   design.rst
   library.rst
   extending.rst
   windows.rst
   gui.rst
   installed.rst
